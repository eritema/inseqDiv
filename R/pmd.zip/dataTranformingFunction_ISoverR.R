## data= data matrix from HISAP where first three colums should be 
## 1= Chromosome 2=IntegrationLocus 3=Number of Reads. Other columns can be any experimental factors 
## Function "dataTransformation" By default use 1,2,4 columns as Insertion site name. (Here i have also defined default for experimental)
## any range can be provided 1 to 6 in experimental factors 
## Final Matrix can be used in any function of inseqDiv package 

dataTransformation<-function(data,ISrange=c(1,2,4),factorRange=c(12,13,14),thr=3){

sortdata<-data[order(data[,1],data[,2]),]
prec<--10
 for (i in 1:dim(sortdata)[1]) {

      # if the location is within thr (3) bases change to the previous
     if (abs(sortdata[i,2]-prec)<=thr) {prec<-sortdata[i,2];sortdata[i,2]<-first;}

      # else is a new IS
     else {first<-sortdata[i,2];prec<-first}
}

CollapseData<-sortdata

IS_vec<-do.call(paste, c(CollapseData[ISrange], sep = "_"))
factor_vec<-do.call(paste, c(CollapseData[factorRange], sep = "_"))
numberOfread_vec<-CollapseData[,3]
dataMatrix<-cbind(factor_vec,IS_vec,numberOfread_vec)

dataMatrix<-transform(dataMatrix, numberOfread_vec = as.numeric(as.character((numberOfread_vec))))

dataMatrix<-as.data.frame(dataMatrix)

abundance <- as.numeric(dataMatrix[,3])

temp<- data.frame(rep(NA, sum(abundance)))

for (i in 1:(ncol(dataMatrix)-1)) {
        temp[,i] <- rep(as.character(dataMatrix[,i]), abundance)
    }
finalMat<- table(temp)
finalMat<-t(as.data.frame.matrix(finalMat))
return(finalMat)
}
